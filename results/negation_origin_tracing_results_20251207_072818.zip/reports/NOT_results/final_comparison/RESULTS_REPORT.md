# Probe Comparison Results
Total experiments: 18
Successful: 18

## Best Overall
- **Layer**: 5
- **Pooling**: mean
- **Test AUROC**: 0.9236
- **Test Accuracy**: 0.8440
- **Checkpoint**: `/content/drive/MyDrive/NOT_results/sweep_mean/checkpoints/layer5_mean/best-val_acc=0.844.ckpt`

## Results by Pooling Strategy

### CLS Pooling

| Layer | AUROC | Accuracy |
|-------|-------|----------|
| 0 | 0.8189 | 0.7489 |
| 1 | 0.8156 | 0.7408 |
| 2 | 0.8436 | 0.7695 |
| 3 | 0.8576 | 0.7970 |
| 4 | 0.8892 | 0.8154 |
| 5 | 0.9208 | 0.8463 |

### MEAN Pooling

| Layer | AUROC | Accuracy |
|-------|-------|----------|
| 0 | 0.8680 | 0.7970 |
| 1 | 0.8765 | 0.8073 |
| 2 | 0.8810 | 0.8085 |
| 3 | 0.9164 | 0.8394 |
| 4 | 0.9235 | 0.8475 |
| 5 | 0.9236 | 0.8440 |

### TOKEN Pooling

| Layer | AUROC | Accuracy |
|-------|-------|----------|
| 0 | 0.8083 | 0.7374 |
| 1 | 0.8128 | 0.7489 |
| 2 | 0.8400 | 0.7706 |
| 3 | 0.8547 | 0.7970 |
| 4 | 0.8869 | 0.8177 |
| 5 | 0.9172 | 0.8440 |

## Results by Layer

- **Layer 0**: Best with mean pooling (AUROC: 0.8680)
- **Layer 1**: Best with mean pooling (AUROC: 0.8765)
- **Layer 2**: Best with mean pooling (AUROC: 0.8810)
- **Layer 3**: Best with mean pooling (AUROC: 0.9164)
- **Layer 4**: Best with mean pooling (AUROC: 0.9235)
- **Layer 5**: Best with mean pooling (AUROC: 0.9236)
