# Transfer Evaluation Report

Generated: 2025-12-03 22:16:03

## Overview

- **Dataset**: JinaAI Negation Dataset
- **Test pairs**: 500
- **Probes evaluated**: 18
- **Model**: DistilBERT (distilbert-base-uncased)

## Results Summary

### Best Configuration

| Metric | Value |
|--------|-------|
| Layer | 3 |
| Pooling | MEAN |
| Flip Accuracy | 0.422 |
| Combined Score | 0.533 |

### All Results

| Layer | Pooling | Flip Acc | Confidence | Combined | Val Acc |
|-------|---------|----------|------------|----------|----------|
| 3 | MEAN | 0.422 | 0.791 | 0.533 | 0.839 |
| 0 | TOKEN | 0.434 | 0.676 | 0.507 | 0.737 |
| 4 | CLS | 0.372 | 0.811 | 0.504 | 0.815 |
| 4 | MEAN | 0.380 | 0.784 | 0.501 | 0.847 |
| 0 | MEAN | 0.378 | 0.771 | 0.496 | 0.797 |
| 4 | TOKEN | 0.354 | 0.819 | 0.493 | 0.818 |
| 5 | MEAN | 0.352 | 0.807 | 0.488 | 0.844 |
| 2 | TOKEN | 0.380 | 0.741 | 0.488 | 0.771 |
| 1 | MEAN | 0.352 | 0.791 | 0.484 | 0.807 |
| 2 | MEAN | 0.334 | 0.799 | 0.473 | 0.808 |
| 0 | CLS | 0.404 | 0.634 | 0.473 | 0.749 |
| 1 | TOKEN | 0.348 | 0.723 | 0.461 | 0.749 |
| 5 | CLS | 0.284 | 0.828 | 0.447 | 0.846 |
| 2 | CLS | 0.308 | 0.759 | 0.443 | 0.769 |
| 1 | CLS | 0.334 | 0.675 | 0.436 | 0.741 |
| 5 | TOKEN | 0.236 | 0.852 | 0.421 | 0.844 |
| 3 | TOKEN | 0.236 | 0.800 | 0.405 | 0.797 |
| 3 | CLS | 0.218 | 0.808 | 0.395 | 0.797 |

## Hypothesis Test: Layer 3 Distillation

**Hypothesis**: Negation understanding is compressed into Layer 3 in DistilBERT
(corresponding to BERT layers 7/9).

| Metric | Value |
|--------|-------|
| Layer 3 mean score | 0.444 |
| Other layers mean | 0.474 |
| t-statistic | -1.287 |
| p-value | 0.2165 |

**Conclusion**: NO SIGNIFICANT DIFFERENCE. Cannot confirm Layer 3 has special negation understanding.

## Visualizations

- `transfer_evaluation.png`: Main evaluation plots
- `distillation_pattern.png`: Expected vs actual distillation pattern

## Files

- `results.json`: Raw evaluation results
- `TRANSFER_REPORT.md`: This report
